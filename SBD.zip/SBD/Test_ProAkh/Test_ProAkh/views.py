from django.shortcuts import render
from django.contrib import auth

def form(request):
    return render(request, "Form_Test.html")


